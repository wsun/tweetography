import processing.core.*; 
import processing.xml.*; 

import processing.opengl.*; 
import codeanticode.glgraphics.*; 
import de.fhpotsdam.unfolding.*; 
import de.fhpotsdam.unfolding.core.*; 
import de.fhpotsdam.unfolding.geo.*; 
import de.fhpotsdam.unfolding.utils.*; 
import de.fhpotsdam.unfolding.providers.*; 
import de.fhpotsdam.unfolding.mapdisplay.AbstractMapDisplay; 
import de.fhpotsdam.unfolding.tiles.MBTilesLoaderUtils; 
import de.fhpotsdam.unfolding.geo.MercatorProjection; 
import wordcram.*; 
import wordcram.text.*; 
import controlP5.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class finalProject extends PApplet {

// tweetography beta: mapping you and your world














PFont plain, italics;

de.fhpotsdam.unfolding.Map map;

ControlP5 controlP5;
ArrayList<City> cities = new ArrayList<City>();
City[] selectedCities = new City[0];
City[] aggregate = new City[0];
int imageWidth = 900;
int imageHeight = 600;
int margin = 40;
int plot_x1, plot_x2, plot_y1, plot_y2;
WordCram wordCram;
String bigString;
boolean analyze = false;
boolean time = false;
int[] button = new int[4];
int counter = 1;
MultiList the_list;

// selection tool variables
int sizeSelection = 50;

public void setup() {
  background(0);
  plain = loadFont("plain.vlw");
  italics = loadFont("italic.vlw");
  // add controlP5 interface
  controlP5 = new ControlP5(this);
  controlP5.addButton("Home", 10, 10, 20, 80, 19); 
  controlP5.addButton("Analyze", 10, 10, 60, 80, 19);
  controlP5.addButton("Play", 10, 10, 100, 80, 19); 
  controlP5.addButton("Mood", 10, 10, 140, 80, 19); 
  
  // plot size
  size(1400, 800);
  map = new de.fhpotsdam.unfolding.Map(this, 0, 0, width, height, new customMBTilesMapProvider("jdbc:sqlite:" + dataPath("tiles/control-room.mbtiles") + "")); 
  plot_x1 = 0;
  plot_x2 = 1400;
  plot_y1 = 0;
  plot_y2 = 800;
  button[0] = plot_x2 + 210;
  button[1] = plot_y2 - 70;
  button[2] = plot_x2 + 260;
  button[3] = plot_y2;
  map.setTweening(true);
  Location centerLocation = new Location(40, 10);
  map.zoomAndPanTo(centerLocation, 2);
  MapUtils.createDefaultEventDispatcher(this, map);

  // filling the screen a bit.
  for (City c:loadCitiesFromCsv("cities/us.csv")) {
    cities.add(c);
  }
  noStroke();
}

public void draw() {
  
  if (analyze == false) {
    map.draw();
    title();
    legend();
    if (time == false) {
      for (City c:cities) {
        c.tick();
        float xy[] = map.getScreenPositionFromLocation(new Location(c.lat, c.lng));
        float x = xy[0];
        float y = xy[1];
        float markerRadius = constrain(map.getZoom()/10, 1, 20) * 4;
      }
      selectionCircle();
    }
    else {
      calendar();
      aggregate = (City[]) append(aggregate, cities.get(cities.size()-counter));
      for (City c:aggregate) {
        c.col = 0xffFFFFFF;
        c.tick();
      }
      City c = cities.get(cities.size()-counter);
      float xy[] = map.getScreenPositionFromLocation(new Location(c.lat, c.lng));
      float x = xy[0];
      float y = xy[1];
      fill(0xffFF6600, 150);
      noStroke();
      ellipse(x, y, 20, 20);
      fill(0xffFF6600);
      textFont(plain);
      String s = cities.get(cities.size()-counter).datetime;
      int first = s.indexOf('/');
      int next = s.lastIndexOf('/');
      String the_month = getMonthForInt(PApplet.parseInt(s.substring(0, first)));
      String the_day = s.substring(first+1, next);
      String the_time = s.substring(next+4);     
      textMode(CENTER);
      textSize(20);
      text(the_month + " " + the_day, width-160, 630);
      fill(0xffFFFFFF);
      text(the_time + " (24 hr)", width-173, 680);
      
      counter++;
      if (counter > cities.size()) {
        time = false;
        counter = 0;
      }
    }
  }
  else {
    
     // wordcram
     
     PImage title;
     title = loadImage("cram.png");
     image(title, 0, 0);
     title();
     // basicStats
     float sumStatuses = 0;
     float sumFollowers = 0;
     float sumFriends = 0;
     float sumMood = 0;
     for(City c:cities) {
       sumStatuses += c.statuses;
       sumFollowers += c.followers;
       sumFriends += c.friends;
       sumMood += c.mood;
     }
     sumStatuses = sumStatuses/cities.size();
     sumFollowers = sumFollowers/cities.size();
     sumFriends = sumFriends/cities.size();
     sumMood = sumMood/cities.size();
     
     textSize(20);
     fill(0xffFFFFFF);
     int x = 157;
     int y = 750;
     text(sumStatuses, x-75, y);
     text(sumFollowers, 3.3f*x-75, y);
     text(sumFriends, 5.7f*x-75, y);
     text(sumMood, 8*x-75, y);
     
     fill(0xffFF6103);
     y = 725;
     textMode(RIGHT);
     text("Average no. of statuses", x-75, y);
     text("Average no. of followers", 3.3f*x-75, y);
     text("Average no. of friends", 5.7f*x-75, y);
     text("Average mood (0-4)", 8*x-75, y);
     
     fill(0xffFF6103);
     textMode(LEFT);
     textSize(40);
     y+=20;
     text("*", x-105, y);
     text("*", 3.3f*x-105, y);
     text("*", 5.7f*x-105, y);
     text("*", 8*x-105, y);
  }
}

public void keyPressed() {
  if (key == '=') 
    map.zoomLevelIn();
  if (key == '_')
    map.zoomLevelOut();
  if (key == 'h') {
    Location centerLocation = new Location(40, 10);
    map.zoomAndPanTo(centerLocation, 2);
  }
  if (key == 'r') {
    selectedCities = new City[0];
    Location centerLocation = new Location(40, 10);
    map.zoomAndPanTo(centerLocation, 2);
    for (City c:cities)
      c.col = 0xffFFFFFF;
  } 
}

public String getMonthForInt(int m) {
    String month = "invalid";
    DateFormatSymbols dfs = new DateFormatSymbols();
    String[] months = dfs.getMonths();
    if (m >= 0 && m <= 11 ) {
        month = months[m-1];
    }
    return month;
}

public boolean near(float x, float y, float diameter) {
  float disX = x - mouseX;
  float disY = y - mouseY;
  if(sqrt(sq(disX) + sq(disY)) < diameter/2 ) 
    return true;
  else 
    return false;
}


// tweet selection

public void selectionCircle() {
  if (mouseX > plot_x1 && mouseX < plot_x2 && mouseY > plot_y1 && mouseY < plot_y2) {
      
      if (mouseX > 150 && mouseY > 150) {
        // draw bounding box
        ellipseMode(CENTER); stroke(0xffFFFFFF); strokeWeight(1); fill(0xffFFFFFF, 50); smooth();
        ellipse(mouseX, mouseY, sizeSelection, sizeSelection);
      }
  } 
}

public void mouseClicked() {
  float circleX, circleY;
  if (mouseX > plot_x1 && mouseX < plot_x2 && mouseY > plot_y1 && mouseY < plot_y2) {
     // draw bounding box
      if (mouseX < 161 && mouseY < 156) {}
      else {
        ellipseMode(CENTER); stroke(0xffFFFFFF); strokeWeight(1); fill(0xffFFFFFF, 50); smooth();
        ellipse(mouseX, mouseY, sizeSelection, sizeSelection);
      }
  }
  
  for (City c:cities) {
    float xy[] = map.getScreenPositionFromLocation(new Location(c.lat, c.lng));
    float x = xy[0];
    float y = xy[1];
    if (near(x, y, sizeSelection)) {
      c.col = 0xffFF6103;
      selectedCities = (City[]) append(selectedCities, c);
    }
  }
} 

public void Analyze() {
  float x = mouseX;
  float y = mouseY;
  if (selectedCities.length != 0) {
    getWordCram();
    background(0xffFFFFFF);
    analyze = true;
  }
  else {
    fill(0xffFFFFFF);
    textFont(italics);
    textSize(15);
    text("please select some tweets", 10, 150);
  }
}

public void title() {
  textMode(LEFT);
  textFont(plain);
  textSize(70);
  fill(0xffFF6103);
  if (!analyze) 
    text("tweetography", width-width/3, 80);
  else
    text("inspection", width-width/3, 80);
}

public void calendar() {
  rectMode(CORNERS);
  fill(110, 40);
  rect(width-200, 610, width-50, 640);
  rect(width-200, 660, width-50, 690); 
} 

public void legend() {
  fill(0xffFF6600);
  textFont(italics);
  textSize(15);
  text("map interface", 20, 660);
  fill(0xffFFFFFF);
  textFont(plain);
  textSize(15);
  text("up, down, right, left arrows to pan", 20, 680);
  text("-, + keys to zoom", 20, 700);
  text("'h' to resize, 'r' to refresh", 20, 720);
  text("'click' to select tweets", 20, 740);
  text("return to map", 100, 20+12);
  text("inspect the data", 100, 60+12);
  text("tweets over time", 100, 100+12); 
  text("gauge global mood", 100, 140+12); 
}

public void Home() {
  analyze = false;
}

public void Play() {
  if (analyze == false)
    time = true;
}

public void Mood() {
  if (analyze == false) {
    for (City c: cities) {
      int mood = c.mood;
      if (mood==0)
        c.col = 0xffCD0000;
      else if (mood==2) 
        c.col =  0xff0276FD;
      else
        c.col = 0xff33FF33;
    }
  }
}
    
    

public void getWordCram() {
  // append strings
  String[] tweets = new String[0];
  for (City c: cities)
    tweets = append(tweets, c.tweet);  
  bigString = join(tweets, ","); 
  background(0);
  wordCram = new WordCram(this)
    .fromTextString(bigString)
    .withFonts(PFont.list())
    .withPlacer(Placers.centerClump())
    .sizedByWeight(12, 60)
    .withColors(color(234, 21, 122), color (0, 112, 192), color (26, 179, 159));
  wordCram.drawAll();
  saveFrame("cram.png");
}
class City {
  int id, statuses, followers, friends, mood;
  Location location;
  float x, y, lat, lng, markerRadius;
  String tweet, datetime;
  int col;
  boolean mouseOver;

  City(float lat, float lng, String tweet, String datetime, int statuses, int followers, int friends, int mood) {
    this.lat = lat;
    this.lng = lng;
    this.tweet = tweet;
    this.datetime = datetime;
    this.statuses = statuses;
    this.followers = followers;
    this.friends = friends;
    this.mood = mood;
    col = 0xffFFFFFF;
    location = new Location(lat, lng);
    tick();
  }   
      
  public void tick() {
    float xy[] = map.getScreenPositionFromLocation(location);
    x = xy[0];
    y = xy[1];
    if (onScreen()) {
      draw();
    }
  }
  
  public void draw() {
    markerRadius = constrain(map.getZoom()/10, 1, 20) * 8;
    fill(col);
    ellipse(x, y, markerRadius/3, markerRadius/3);
    fill(col, 40);
    noStroke();
    ellipse(x, y, markerRadius, markerRadius);
  }
  
  public boolean onScreen() {
    if (x > -markerRadius && x < width + markerRadius && y > -markerRadius && y < height + markerRadius) {
      return true;
    } 
    else {
      return false;
    }
  }

}
class customMBTilesMapProvider extends AbstractMapTileProvider {
  protected String jdbcConnectionString;

  public customMBTilesMapProvider() {
    super(new MercatorProjection(26, new Transformation(1.068070779e7f, 0.0f, 3.355443185e7f, 0.0f, 
    -1.068070890e7f, 3.355443057e7f)));
  }

  public customMBTilesMapProvider(String jdbcConnectionString) {
    this();
    this.jdbcConnectionString = jdbcConnectionString;
  }

  public int tileWidth() {
    return 256;
  }

  public int tileHeight() {
    return 256;
  }

  public PImage getTile(Coordinate coord) {
    float gridSize = PApplet.pow(2, coord.zoom);
    float negativeRow = gridSize - coord.row - 1;

    return MBTilesLoaderUtils.getMBTile((int) coord.column, (int) negativeRow, (int) coord.zoom, jdbcConnectionString);
  }
}

public City[] loadCitiesFromCsv(String file) {
  City[] result = new City[0];
  print("loading " + file + "... ");
  String[] lines = loadStrings(file);
  for (String line:lines) {
    String[] fields = split(line, ',');      
    if(fields.length == 14)
      result = (City[]) append(result, new City(PApplet.parseFloat(fields[11]), PApplet.parseFloat(fields[12]), fields[4], fields[0], PApplet.parseInt(fields[7]), PApplet.parseInt(fields[8]), PApplet.parseInt(fields[9]), PApplet.parseInt(fields[13])));
  }
  println("done! Loaded " + lines.length + " cities.");
  return result;
}
  static public void main(String args[]) {
    PApplet.main(new String[] { "--present", "--bgcolor=#666666", "--stop-color=#cccccc", "finalProject" });
  }
}
